(function ($) {
    $(function () {

        $('.slider-menu').slick({
            infinite: true,
            slidesToShow: 1,
            slidesToScroll: 1,
            prevArrow: '<div class="slick-prev">&#10094;</div>',
            nextArrow: '<div class="slick-next">&#10095;</div>',
            responsive: [
                {
                    breakpoint: 1201,
                    settings: {
                        arrows: false
                    }
                }
                ]
        });



        $('.our-project-gallery').slick({
            infinite: true,
            slidesToShow: 5,
            slidesToScroll: 1,
            prevArrow: '<div class="slick-prev">&#10094;</div>',
            nextArrow: '<div class="slick-next">&#10095;</div>',

            responsive: [
                {
                    breakpoint: 1281,
                    settings: {
                        slidesToShow: 4
                    }
                },
                {
                    breakpoint: 1201,
                    settings: {
                        slidesToShow: 3,
                        arrows: false
                    }
                },

                {
                    breakpoint: 769,
                    settings: {
                        slidesToShow: 2,
                        arrows: false
                    }
                },
                {
                    breakpoint: 481,
                    settings: {
                        slidesToShow: 1,
                        arrows: false
                    }
                }
        ]
        });

        $('.menuToggle').on('click', function (){
            $('.main-menu-phone').addClass('main-menu-phone-active');
            $('body').addClass('fixed');

        });
        $('.menu-close').on('click', function (){
            $('.main-menu-phone').removeClass('main-menu-phone-active');
            $('body').removeClass('fixed');

        });
});
////
})(jQuery);
